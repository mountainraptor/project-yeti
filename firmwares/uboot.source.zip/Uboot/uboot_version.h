/*
 *
 * w.x.y.z
 * w = significant change	
 * x = major change		(formal release) 
 * y = minor change		(bug fix release)
 * z = internal change		(internal debuging)
 */
#define RALINK_LOCAL_VERSION    "4.0.0.0"
